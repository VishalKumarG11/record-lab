import React, { useState, useRef, useEffect } from 'react';
import { TopNavbar } from './components/TopNavbar';
import { LeftDock } from './components/LeftDock';
import { ThemeInspector } from './components/ThemeInspector';
import { CenterStage } from './components/CenterStage';
import { Timeline } from './components/Timeline';
import type { AspectRatioType, QualityType, MousePoint, ResolutionPreset } from './types';

const RESOLUTION_PRESETS: Record<QualityType, ResolutionPreset> = {
  '240':  { width: 426,  height: 240,  bitrate: 800000 },
  '360':  { width: 640,  height: 360,  bitrate: 1500000 },
  '720':  { width: 1280, height: 720,  bitrate: 6000000 },
  '1080': { width: 1920, height: 1080, bitrate: 14000000 },
  '2160': { width: 3840, height: 2160, bitrate: 45000000 },
};

export const App: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [canPreview, setCanPreview] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState('0:00');
  const [totalTime, setTotalTime] = useState('0:00');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioType>('16:9');
  const [selectedQuality, setSelectedQuality] = useState<QualityType>('1080');
  const [exportStatus, setExportStatus] = useState('');
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [bgStyle, setBgStyle] = useState<React.CSSProperties>({
    background: 'linear-gradient(135deg, #38bdf8 0%, #6366f1 50%, #d946ef 100%)',
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const mouseDataRef = useRef<MousePoint[]>([]);
  const animFrameRef = useRef<number | null>(null);

  const zoomState = useRef({
    currentScale: 1.0,
    currentFocusX: 960,
    currentFocusY: 540,
    stableScale: 1.0,
    stableTargetX: 960,
    stableTargetY: 540,
    zoomHoldUntil: 0,
  });

  useEffect(() => {
    const video = document.createElement('video');
    video.playsInline = true;
    videoRef.current = video;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && videoRef.current && videoRef.current.duration) {
        e.preventDefault();
        togglePlayPause();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const formatSeconds = (sec: number) => {
    if (isNaN(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const drawFrame = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoomState.current.currentScale, zoomState.current.currentScale);
    ctx.translate(-zoomState.current.currentFocusX, -zoomState.current.currentFocusY);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    ctx.restore();
  };

  const startZoomLoop = () => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);

    const lerp = (start: number, end: number, f: number) => start + (end - start) * f;

    const render = () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video && canvas && !video.paused && !video.ended) {
        const currentTimeMs = video.currentTime * 1000;
        setCurrentTime(formatSeconds(video.currentTime));

        if (mouseDataRef.current.length > 0) {
          const recent = mouseDataRef.current.filter(
            p => p.time >= currentTimeMs - 350 && p.time <= currentTimeMs
          );

          if (recent.length >= 2) {
            const first = recent[0];
            const last = recent[recent.length - 1];
            const delta = Math.hypot(last.x - first.x, last.y - first.y);
            const isTaskbar = last.y > (window.screen.height - 70);

            if (delta > 260 || isTaskbar) {
              zoomState.current.stableScale = 1.0;
              zoomState.current.stableTargetX = canvas.width / 2;
              zoomState.current.stableTargetY = canvas.height / 2;
              zoomState.current.zoomHoldUntil = 0;
            } else if (delta > 15 && delta < 180) {
              zoomState.current.stableScale = 1.32;
              const rawX = (last.x / window.screen.width) * canvas.width;
              const rawY = (last.y / window.screen.height) * canvas.height;
              const halfW = canvas.width / (2 * zoomState.current.stableScale);
              const halfH = canvas.height / (2 * zoomState.current.stableScale);

              zoomState.current.stableTargetX = Math.max(halfW, Math.min(rawX, canvas.width - halfW));
              zoomState.current.stableTargetY = Math.max(halfH, Math.min(rawY, canvas.height - halfH));
              zoomState.current.zoomHoldUntil = currentTimeMs + 1600;
            }
          }
        }

        if (currentTimeMs > zoomState.current.zoomHoldUntil) {
          zoomState.current.stableScale = 1.0;
          zoomState.current.stableTargetX = canvas.width / 2;
          zoomState.current.stableTargetY = canvas.height / 2;
        }

        zoomState.current.currentScale = lerp(zoomState.current.currentScale, zoomState.current.stableScale, 0.03);
        zoomState.current.currentFocusX = lerp(zoomState.current.currentFocusX, zoomState.current.stableTargetX, 0.03);
        zoomState.current.currentFocusY = lerp(zoomState.current.currentFocusY, zoomState.current.stableTargetY, 0.03);

        drawFrame();
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();
  };

  const startRecording = async () => {
    try {
      setIsRecording(true);
      setCanPreview(false);
      const sources = await window.electronAPI.getSources();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: sources[0].id,
            minWidth: 1280,
            maxWidth: 1920,
            minHeight: 720,
            maxHeight: 1080,
          },
        } as any,
      });

      recordedChunksRef.current = [];
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const video = videoRef.current;
        if (!video) return;

        video.src = URL.createObjectURL(blob);
        video.load();

        video.onloadedmetadata = () => {
          if (canvasRef.current) {
            canvasRef.current.width = video.videoWidth || 1920;
            canvasRef.current.height = video.videoHeight || 1080;
            zoomState.current.currentFocusX = canvasRef.current.width / 2;
            zoomState.current.currentFocusY = canvasRef.current.height / 2;
          }
          setTotalTime(formatSeconds(video.duration));
          video.play();
          setIsPlaying(true);
          startZoomLoop();
          setCanPreview(true);
        };
      };

      mediaRecorderRef.current = recorder;
      await window.electronAPI.startMouseTracking();
      recorder.start(200);
    } catch (err) {
      console.error(err);
      setIsRecording(false);
    }
  };

  const stopRecording = async () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
      mouseDataRef.current = await window.electronAPI.stopMouseTracking();
    }
    setIsRecording(false);
  };

  const togglePlayPause = () => {
    const video = videoRef.current;
    if (!video || !video.duration) return;

    if (video.paused) {
      video.play();
      setIsPlaying(true);
      startZoomLoop();
    } else {
      video.pause();
      setIsPlaying(false);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      drawFrame();
    }
  };

  const handleExport = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || !video.duration) return;

    setExportStatus(`Exporting (${selectedQuality}p)...`);
    const preset = RESOLUTION_PRESETS[selectedQuality];

    video.currentTime = 0;
    video.pause();

    const canvasStream = canvas.captureStream(60);
    const chunks: Blob[] = [];
    const exportRecorder = new MediaRecorder(canvasStream, {
      mimeType: 'video/webm',
      videoBitsPerSecond: preset.bitrate,
    });

    exportRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    exportRecorder.onstop = () => {
      const finalBlob = new Blob(chunks, { type: 'video/webm' });
      const url = URL.createObjectURL(finalBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `recordly-${selectedQuality}p-${Date.now()}.webm`;
      a.click();

      setExportStatus('Export Complete!');
      setTimeout(() => setExportStatus(''), 3000);
      video.play();
      setIsPlaying(true);
      startZoomLoop();
    };

    exportRecorder.start();
    await video.play();
    startZoomLoop();

    video.onended = () => {
      exportRecorder.stop();
      video.onended = null;
    };
  };

  return (
    <div className="app-shell flex flex-col h-screen overflow-hidden">
      <TopNavbar
        isRecording={isRecording}
        canPreview={canPreview}
        canExport={canPreview}
        exportStatus={exportStatus}
        selectedQuality={selectedQuality}
        onQualityChange={setSelectedQuality}
        onStartRecord={startRecording}
        onStopRecord={stopRecording}
        onExport={handleExport}
      />

      <div className="workspace flex flex-1 relative overflow-hidden">
        <LeftDock
          isThemeOpen={isThemeOpen}
          onToggleTheme={() => setIsThemeOpen(prev => !prev)}
        />

        <ThemeInspector
          isOpen={isThemeOpen}
          onClose={() => setIsThemeOpen(false)}
          onSelectBackground={(bg) => setBgStyle({ background: bg })}
          onUploadCustomBg={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              const reader = new FileReader();
              reader.onload = (event) => {
                setBgStyle({
                  backgroundImage: `url(${event.target?.result})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                });
              };
              reader.readAsDataURL(file);
            }
          }}
        />

        <CenterStage
          ref={canvasRef}
          aspectRatio={aspectRatio}
          backgroundStyle={bgStyle}
          onAspectRatioChange={setAspectRatio}
          onCanvasClick={togglePlayPause}
        />
      </div>

      <Timeline
        isPlaying={isPlaying}
        currentTime={currentTime}
        totalTime={totalTime}
        onTogglePlay={togglePlayPause}
        canPlay={canPreview}
      />
    </div>
  );
};
export default App;