import React from 'react';
import { Download, FileVideo, Play, Square } from 'lucide-react';
import type { QualityType } from '../types';

interface TopNavbarProps {
  isRecording: boolean;
  canPreview: boolean;
  canExport: boolean;
  exportStatus: string;
  selectedQuality: QualityType;
  onQualityChange: (quality: QualityType) => void;
  onStartRecord: () => void;
  onStopRecord: () => void;
  onExport: () => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  isRecording,
  canPreview,
  canExport,
  exportStatus,
  selectedQuality,
  onQualityChange,
  onStartRecord,
  onStopRecord,
  onExport,
}) => {
  return (
    <header className="top-bar flex items-center justify-between z-30 shrink-0">
      <div className="flex items-center gap-3">
        <div className="brand-mark"><FileVideo size={15} strokeWidth={2.5} /></div>
        <div className="project-chip">
          <span className={`status-light ${isRecording ? 'recording' : ''}`} />
          <span>recording-studio.recordly</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <select
          value={selectedQuality}
          disabled={isRecording || !canExport}
          onChange={(e) => onQualityChange(e.target.value as QualityType)}
          className="quality-select outline-none cursor-pointer"
        >
          <option value="240">240p</option>
          <option value="360">360p</option>
          <option value="720">720p HD</option>
          <option value="1080">1080p FHD</option>
          <option value="2160">2160p 4K</option>
        </select>

        {!isRecording ? (
          <button
            onClick={onStartRecord}
            className="record-button"
          >
            <Play size={12} fill="currentColor" /> Start Recording
          </button>
        ) : (
          <button
            onClick={onStopRecord}
            className="record-button"
          >
            <Square size={11} fill="currentColor" /> Stop & Preview
          </button>
        )}

        <button
          onClick={onExport}
          disabled={!canExport || isRecording}
          className="export-button"
        >
          <Download size={13} /> Export MP4
        </button>

        {exportStatus && (
          <span className="text-xs text-blue-400 font-medium animate-pulse ml-1">
            {exportStatus}
          </span>
        )}
      </div>
    </header>
  );
};