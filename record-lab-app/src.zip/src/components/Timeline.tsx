import React from 'react';
import { Film, Pause, Play, Scissors, Sparkles, Plus } from 'lucide-react';

interface TimelineProps {
  isPlaying: boolean;
  currentTime: string;
  totalTime: string;
  onTogglePlay: () => void;
  canPlay: boolean;
}

export const Timeline: React.FC<TimelineProps> = ({
  isPlaying,
  currentTime,
  totalTime,
  onTogglePlay,
  canPlay,
}) => {
  return (
    <footer className="timeline flex flex-col shrink-0">
      <div className="timeline-toolbar flex items-center justify-between">
        <div className="flex gap-2">
          <button className="timeline-button flex items-center gap-1.5"><Plus size={12} /> Add Track</button>
          <button className="timeline-button flex items-center gap-1.5"><Scissors size={12} /> Split</button>
        </div>

        <div className="flex items-center gap-3">
          <span className="font-mono text-xs text-slate-400">{currentTime}</span>
          <button
            onClick={onTogglePlay}
            disabled={!canPlay}
            className="play-button hover:scale-105 active:scale-95 cursor-pointer transition-transform"
          >
            {isPlaying ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" />}
          </button>
          <span className="font-mono text-xs text-slate-400">{totalTime}</span>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-[#8c9a99]">
          <Sparkles size={12} className="text-[#35d0a1]" /> Auto-Zoom Active
        </div>
      </div>

      <div className="timeline-body flex-1 p-2.5 px-4 flex flex-col justify-center gap-1.5">
        <div className="flex justify-between font-mono text-[10px] text-slate-500 border-b border-white/5 pb-1">
          <span>0:00</span>
          <span>0:05</span>
          <span>0:10</span>
          <span>0:15</span>
          <span>0:20</span>
          <span>0:25</span>
          <span>0:30</span>
        </div>

        <div className="clip-bar rounded-md flex items-center px-2.5 text-[11px] font-semibold gap-2">
          <Film size={13} />
          <span>Master Screen Recording Clip</span>
        </div>

        <div className="flex items-center gap-2">
          <span className="timeline-badge text-[10px] font-semibold px-2 py-0.5 rounded-md flex items-center gap-1">
            <Sparkles size={10} /> Dynamic Zoom 1.32x
          </span>
          <span className="timeline-badge text-[10px] font-semibold px-2 py-0.5 rounded-md">
            Focus Lock
          </span>
        </div>
      </div>
    </footer>
  );
};